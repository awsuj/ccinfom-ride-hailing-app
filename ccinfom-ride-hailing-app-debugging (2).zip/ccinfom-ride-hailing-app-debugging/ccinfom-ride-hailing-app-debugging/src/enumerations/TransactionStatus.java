package enumerations;

public enum TransactionStatus {
    COMPLETED,
    ONGOING,
    CANCELLED
}